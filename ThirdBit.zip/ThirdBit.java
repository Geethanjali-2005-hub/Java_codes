public class ThirdBit {

    public static void main(String[] args) {
        int n = 5;      // given number
        int i = 2;  // 3rd bit (1-based indexing)

        // Right shift and mask
        int thirdBit = (n >> (i - 1)) & 1;

        System.out.println("Number: " + n);
        System.out.println("3rd bit value: " + thirdBit);
    }
}
