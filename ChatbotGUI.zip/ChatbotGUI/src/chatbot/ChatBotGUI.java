package chatbot;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ChatBotGUI extends JFrame {

    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;

    public ChatBotGUI() {
        setTitle("Java Chatbot");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Chat display
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(chatArea);

        // Input panel
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        sendButton = new JButton("Send");
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        // Button click action
        sendButton.addActionListener(e -> sendMessage());

        // Enter key action
        inputField.addActionListener(e -> sendMessage());
    }

    private void sendMessage() {
        String userText = inputField.getText().trim();
        if (userText.isEmpty()) return;

        chatArea.append("You: " + userText + "\n");
        inputField.setText("");

        String botReply = getBotResponse(userText);
        chatArea.append("Bot: " + botReply + "\n\n");
    }

    private String getBotResponse(String input) {
        input = input.toLowerCase();
        if (input.contains("hello") || input.contains("hi")) {
            return "Hello! How can I help you?";
        } else if (input.contains("how are you")) {
            return "I'm just a program, but I'm doing great!";
        } else if (input.contains("name")) {
            return "I'm a Java Swing Chatbot.";
        } else if (input.contains("bye")) {
            return "Goodbye! Have a nice day!";
        } else {
            return "Sorry, I don't understand that yet.";
        }
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ChatBotGUI().setVisible(true);
            }
            
        });
    }

    }