module ChatbotGUI {
    requires java.desktop; // needed for Swing
    exports chatbot;
}
