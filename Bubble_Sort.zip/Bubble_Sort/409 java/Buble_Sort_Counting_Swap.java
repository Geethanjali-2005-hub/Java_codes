package Bubble_Sort;

public class Buble_Sort_Counting_Swap {
	
	public static void main(String[] args) {
		
		int[]arr= {88,66,44,22,00,99,77,55,33,11};
		int swap=0;
		for (int i=0; i < arr.length;i++) {
			for (int j=0; j < arr.length-1;j++) {
				if (arr[j]>arr[j+1]) {
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
					swap++;
				}
			}
		}
		
		System.out.println("Sorted Array:");
		for (int i=0;i<=arr.length-1;i++) {
			System.out.println(arr[i]);

		}
		System.out.println("Counting number of Swaps:"+swap);
	}

}
